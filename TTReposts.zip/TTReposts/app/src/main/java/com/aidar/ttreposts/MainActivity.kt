package com.aidar.ttreposts

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("tt", MODE_PRIVATE) }

    // Ищет вкладку «Репосты» на странице профиля и нажимает на неё
    private val clickRepostsJs = """
        (function () {
          var tries = 0;
          var timer = setInterval(function () {
            tries++;
            var els = document.querySelectorAll('[data-e2e="repost-tab"],[role="tab"],p,span');
            for (var i = 0; i < els.length; i++) {
              var e = els[i];
              var txt = (e.textContent || '').trim();
              if (e.getAttribute('data-e2e') === 'repost-tab' || /^(reposts?|репосты)${'$'}/i.test(txt)) {
                e.click();
                clearInterval(timer);
                return;
              }
            }
            if (tries > 20) clearInterval(timer);
          }, 500);
        })();
    """.trimIndent()

    // Листает сетку вниз, пока TikTok подгружает новые ролики; в конце зовёт Android.done()
    private val scrollToEndJs = """
        (function () {
          if (window.__ttScrolling) return;
          window.__ttScrolling = true;
          var last = -1, same = 0, ticks = 0;
          var timer = setInterval(function () {
            ticks++;
            var h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
            window.scrollTo(0, h);
            if (h === last) { same++; } else { same = 0; last = h; }
            if (same >= 6 || ticks > 400) {
              clearInterval(timer);
              window.__ttScrolling = false;
              Android.done();
            }
          }, 900);
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString =
                "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                // Только на странице профиля (/@ник) — открываем вкладку «Репосты»
                if (url != null && url.contains("/@")) {
                    view.evaluateJavascript(clickRepostsJs, null)
                }
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {}
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        openReposts()
    }

    private fun openReposts() {
        val user = prefs.getString("user", null)
        if (user.isNullOrBlank()) askUsername() else
            web.loadUrl("https://www.tiktok.com/@$user?tab=repost&lang=ru")
    }

    private fun askUsername() {
        val input = EditText(this).apply { hint = "Твой ник в ТТ (без @)" }
        AlertDialog.Builder(this)
            .setTitle("Ник в TikTok")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Готово") { _, _ ->
                val u = input.text.toString().trim().removePrefix("@")
                if (u.isNotEmpty()) {
                    prefs.edit().putString("user", u).apply()
                    openReposts()
                } else askUsername()
            }
            .show()
    }

    inner class Bridge {
        @JavascriptInterface
        fun done() {
            runOnUiThread {
                Toast.makeText(
                    this@MainActivity,
                    "Дошёл до конца: внизу самые старые репосты",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun scrollToOldest() {
        Toast.makeText(this, "Листаю до конца, подожди…", Toast.LENGTH_SHORT).show()
        web.evaluateJavascript(scrollToEndJs, null)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Сменить ник")
        menu.add(0, 2, 1, "К репостам")
        menu.add(0, 3, 2, "К самому старому")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        1 -> { askUsername(); true }
        2 -> { openReposts(); true }
        3 -> { scrollToOldest(); true }
        else -> super.onOptionsItemSelected(item)
    }
}

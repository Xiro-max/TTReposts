package com.aidar.ttreposts

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("tt", MODE_PRIVATE) }

    private val mobileUa =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val desktopUa =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    // Ищет вкладку «Репосты» на странице профиля и нажимает на неё
    private val clickRepostsJs = """
        (function () {
          var tries = 0;
          var timer = setInterval(function () {
            tries++;
            var els = document.querySelectorAll('[data-e2e="repost-tab"],[role="tab"],p,span');
            for (var i = 0; i < els.length; i++) {
              var e = els[i];
              var txt = (e.textContent || '').trim();
              if (e.getAttribute('data-e2e') === 'repost-tab' || /^(reposts?|репосты)${'$'}/i.test(txt)) {
                e.click();
                clearInterval(timer);
                return;
              }
            }
            if (tries > 20) clearInterval(timer);
          }, 500);
        })();
    """.trimIndent()

    // Листает сетку вниз, пока TikTok подгружает новые ролики; в конце зовёт Android.done()
    private val scrollToEndJs = """
        (function () {
          if (window.__ttScrolling) return;
          window.__ttScrolling = true;
          var last = -1, same = 0, ticks = 0;
          var timer = setInterval(function () {
            ticks++;
            var h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
            window.scrollTo(0, h);
            if (h === last) { same++; } else { same = 0; last = h; }
            if (same >= 6 || ticks > 400) {
              clearInterval(timer);
              window.__ttScrolling = false;
              Android.done();
            }
          }, 900);
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        applyMode()

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                applyFit()
                // Только на странице профиля (/@ник) — открываем вкладку «Репосты»
                if (url != null && url.contains("/@")) {
                    view.evaluateJavascript(clickRepostsJs, null)
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {}

            // TikTok пытается открыть своё приложение через snssdk1233://...
            // WebView такие ссылки не понимает (ERR_UNKNOWN_URL_SCHEME), поэтому просто игнорируем их
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: return false
                return scheme !in listOf("http", "https", "about", "data", "blob")
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        openReposts()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush() // сохраняем вход в аккаунт
    }

    private fun isDesktop() = prefs.getBoolean("desktop", true)

    // Режим «Версия для ПК»: другой User-Agent и широкий экран
    private fun applyMode() {
        val desktop = isDesktop()
        web.settings.apply {
            userAgentString = if (desktop) desktopUa else mobileUa
            useWideViewPort = desktop
            loadWithOverviewMode = desktop
        }
    }

    private fun viewportWidth() = prefs.getInt("vw", 1200)

    // Задаёт «ширину страницы» в CSS-пикселях: чем она больше, тем мельче всё
    // выглядит, но тем больше помещается на экране
    private fun fitJs(): String = """
        (function () {
          var m = document.querySelector('meta[name=viewport]');
          if (!m) {
            m = document.createElement('meta');
            m.name = 'viewport';
            (document.head || document.documentElement).appendChild(m);
          }
          m.setAttribute('content', 'width=${viewportWidth()},user-scalable=yes');
        })();
    """.trimIndent()

    private fun applyFit() {
        if (!isDesktop()) return
        val js = fitJs()
        web.evaluateJavascript(js, null)
        // TikTok подгружается постепенно, поэтому повторяем
        web.postDelayed({ web.evaluateJavascript(js, null) }, 1500)
        web.postDelayed({ web.evaluateJavascript(js, null) }, 4000)
    }

    private fun changeWidth(delta: Int) {
        val w = (viewportWidth() + delta).coerceIn(600, 2000)
        prefs.edit().putInt("vw", w).apply()
        Toast.makeText(this, "Ширина страницы: $w", Toast.LENGTH_SHORT).show()
        web.evaluateJavascript(fitJs(), null)
    }

    private fun openReposts() {
        val user = prefs.getString("user", null)
        if (user.isNullOrBlank()) askUsername() else
            web.loadUrl("https://www.tiktok.com/@$user?tab=repost&lang=ru")
    }

    private fun askUsername() {
        val input = EditText(this).apply { hint = "Твой ник в ТТ (без @)" }
        AlertDialog.Builder(this)
            .setTitle("Ник в TikTok")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Готово") { _, _ ->
                val u = input.text.toString().trim().removePrefix("@")
                if (u.isNotEmpty()) {
                    prefs.edit().putString("user", u).apply()
                    openReposts()
                } else askUsername()
            }
            .show()
    }

    inner class Bridge {
        @JavascriptInterface
        fun done() {
            runOnUiThread {
                Toast.makeText(
                    this@MainActivity,
                    "Дошёл до конца: внизу самые старые репосты",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun scrollToOldest() {
        Toast.makeText(this, "Листаю до конца, подожди…", Toast.LENGTH_SHORT).show()
        web.evaluateJavascript(scrollToEndJs, null)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Сменить ник")
        menu.add(0, 2, 1, "К репостам")
        menu.add(0, 3, 2, "К самому старому")
        menu.add(0, 4, 3, "Версия для ПК")
        menu.add(0, 5, 4, "Войти в TikTok")
        menu.add(0, 6, 5, "Мельче (больше влезает)")
        menu.add(0, 7, 6, "Крупнее (меньше влезает)")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(4)?.title =
            if (isDesktop()) "Версия для ПК: вкл" else "Версия для ПК: выкл"
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        1 -> { askUsername(); true }
        2 -> { openReposts(); true }
        3 -> { scrollToOldest(); true }
        4 -> {
            prefs.edit().putBoolean("desktop", !isDesktop()).apply()
            applyMode()
            openReposts()
            true
        }
        5 -> { web.loadUrl("https://www.tiktok.com/login"); true }
        6 -> { changeWidth(+150); true }
        7 -> { changeWidth(-150); true }
        else -> super.onOptionsItemSelected(item)
    }
}
